/*
 *  CCTranscriptionEngine.cpp
 *  CCTranscriber
 *
 *  Created by Bebelutz on 5/7/06.
 *  Copyright 2006 __MyCompanyName__. All rights reserved.
 *
 */

#include "CCTranscriptionEngine.h"

#include "CCTempoFinder.h"
#include "CCPitchFinder.h"
#include "CCGlobals.h" // I'm the only one that includes this file!

#include <iostream>
using std::cout;
using std::endl;

//Constructor
CCTranscriptionEngine::CCTranscriptionEngine(unsigned numSamples, float *bufferOfSamples) : mNumSamples(numSamples), mSampleBufferPtr(bufferOfSamples) {
	
	mExperts.push_back(new CCTempoFinder());
	mExperts.push_back(new CCPitchFinder());
	
	mTempoHistory = new float[numSamples / 512];
	
//	for(int i = 0; i < numSamples / 512; i++)
//	{
//		mTempoHistory[i] = 0.0;
//	}

}

CCTranscriptionEngine::~CCTranscriptionEngine() { 
	
	delete [] mTempoHistory;

}


void CCTranscriptionEngine::judge()
{
	float *sampleBufferPtr = mSampleBufferPtr;
	int samplesLeft = (int)mNumSamples;
	unsigned increment = 512;
	
	int i = 0;
	list<CCAbstractExpert *>::iterator expert;
	expert = mExperts.begin();	//refer to tempo expert
	
	while (samplesLeft > 0) {
		gFeatureList.currentItem()->setSampleBuffer(sampleBufferPtr); // Set the pointer of the current feature item to look at the buffer of samples.
		gFeatureList.currentItem()->calculateBasicStats(); // Precaluclate some data.
		CCExpertGroup::judge(); // Call the superclass version of this function, so it calls judge on each of my children.
		
		mTempoHistory[i] = (*expert)->verdict();  //get final verdict of CCTempoFinder and add to mTempoHistory
		
//		cout << "i = " << i << "\n";
//		cout << "verdict() = " << (*expert)->verdict() << "\n";
//		cout << "mTempoHistory = " << mTempoHistory[i] << "\n";	

		i++;		
																						
		gFeatureList.advanceCurrentItem();

		// Make sure to request only the needed samples at the end of the file.
		// TODO: zero out the buffer, so that the remaining samples don't show garbage.
		if(samplesLeft < increment) 
			increment = samplesLeft;
		
		sampleBufferPtr += increment;
		samplesLeft -= increment;
	} // end of while loop
	
	for(i = 0; i < mNumSamples / 512; i++)
	{
		mVerdict += mTempoHistory[i];
	}
		
	mVerdict = mVerdict * 512 / mNumSamples;
	
}

void CCTranscriptionEngine::judge(float *sampleBuffer)
{
	float *sampleBufferPtr = mSampleBufferPtr;
	unsigned increment = 512;
	
		gFeatureList.currentItem()->setSampleBuffer(sampleBufferPtr); // Set the pointer of the current feature item to look at the buffer of samples.
		gFeatureList.currentItem()->calculateBasicStats(); // Precaluclate some data.
		
		CCExpertGroup::judge(); // Call the superclass version of this function, so it calls judge on each of my children.

		gFeatureList.advanceCurrentItem();

		
}

float CCTranscriptionEngine::tempoAtBlock(unsigned blockNumber)
{
	return mTempoHistory[blockNumber];
}