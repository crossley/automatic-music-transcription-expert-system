/*
 *  CCTempoFinder.cpp
 *  CCTranscriber
 *
 *  Created by Bebelutz on 5/7/06.
 *  Copyright 2006 __MyCompanyName__. All rights reserved.
 *
 */

#include "CCPitchFinder.h"
#include "CCFeatures.h"
#include "CCore.h"

extern CCFeatureList gFeatureList;

#include <iostream>
using std::cout;
using std::endl;

//Constructor
CCPitchFinder::CCPitchFinder()
{
	
	mExperts.push_back(new CCPitchExpertA());
	mExperts.push_back(new CCPitchExpertB());

}

void CCPitchExpertA::judge()
{
	float *spectrumBufferPtr = gFeatureList.currentItem()->fourierSpectrumBuffer();
	unsigned bufferSize = gFeatureList.statsBufferSize();
	
	// find the highest peak in the buffer
	unsigned peakIndex = findAbsPeakIndex(spectrumBufferPtr, bufferSize);
//	peak = spectrumBufferPtr[index];
	
	float peakFrequency = (float) gFeatureList.mSampleRate * (float)peakIndex * 0.5 / (float)bufferSize;
	
	mVerdict = peakFrequency;
	
//	cout << mVerdict << endl;
}

void CCPitchExpertB::judge()
{
//	float *aCorrBufferIn = gFeatureList.currentItem->fourierSpectrumBuffer();
//	float absPeak = gFeatureList.rmsAutocorPeak(); 	// find absPeakInd
//	unsigned bufferSize = gFeatureList.statsBufferSize();
//	float peak = 0.0;
//	unsigned peakIndex;
//	
//	//choose an arbitrary (for now) threshold to pick peaks out of noise
//	for(unsigned i = 5; i < bufferSize - 5; i++){
//		if (isLocalPeak(aCorrBufferIn, i) && aCorrBufferIn[i] >= 0.8 * absPeak) {
//			peak = aCorrBufferIn[i];
//			peakIndex = i;
//			break;
//		}
//	}
//	
//	//assume first window counts as first beat
//	float sampleRate = gFeatureList.mSampleRate;
//	float tempo = ((float) sampleRate / (bufferSize * peakIndex)) * 60;
//	
//	mVerdict = tempo;
//	cout << mVerdict << endl;
	
}

