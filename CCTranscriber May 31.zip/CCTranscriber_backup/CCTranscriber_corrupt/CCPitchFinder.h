/*
 *  CCTempoFinder.h
 *  CCTranscriber
 *
 *  Created by Bebelutz on 5/7/06.
 *  Copyright 2006 __MyCompanyName__. All rights reserved.
 *
 */


#ifndef CC_PITCH_FINDER_H			// In case you include this twice
#define CC_PITCH_FINDER_H

#include "CCExpert.h"

class CCPitchFinder : public CCExpertGroup {
public:
	CCPitchFinder();						///< empty constructor
	virtual ~CCPitchFinder() { };				///< virtual destructor
										/// Clients call judge() to get the features of a buffer.
};

class CCPitchExpertA : public CCExpert {
public:
	CCPitchExpertA();
	virtual ~CCPitchExpertA() { };				///< virtual destructor
										/// Clients call judge() to get the features of a buffer.
	virtual void judge();		///< makes a judgment on the tempo of a block of samples.
		
};

class CCPitchExpertB : public CCExpert {
public:
	CCPitchExpertB() { };						///< empty constructor
	virtual ~CCPitchExpertB() { };				///< virtual destructor
										/// Clients call judge() to get the features of a buffer.
	virtual void judge();		///< this will be implemented in subclasses.
		
};


#endif