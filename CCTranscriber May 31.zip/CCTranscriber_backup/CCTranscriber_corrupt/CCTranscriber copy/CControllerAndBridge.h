/* controllerAndBridge */

#import <Cocoa/Cocoa.h>

#include "sndfile.h"

#include "CCTranscriptionEngine.h"
#import "JCWaveformView.h"

@interface CControllerAndBridge : NSObject
{
	CCTranscriptionEngine *musicTranscriber;
	NSString *mFilePath;
	SNDFILE *inFile;
	SF_INFO soundFileInfo;
	IBOutlet NSWindow *myWindow;
	NSProgressIndicator *progressBar;
	JCWaveformView *plotView;
	JCWaveformView *waveZoomView;	
	JCWaveformView *statsView;	
	float *songBufferPtr;
}

- (void)cursorPositionChanged:(NSNotification *)notification;

@end
