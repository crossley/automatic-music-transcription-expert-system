/*
 *  CCTempoFinder.cpp
 *  CCTranscriber
 *
 *  Created by Bebelutz on 5/7/06.
 *  Copyright 2006 __MyCompanyName__. All rights reserved.
 *
 */

#include "CCTempoFinder.h"
#include "CCFeatures.h"
#include "CCore.h"

extern CCFeatureList gFeatureList;

#include <iostream>
using std::cout;
using std::endl;

//Constructor
CCTempoFinder::CCTempoFinder()
{
	
	mExperts.push_back(new CCTempoExpertA());
	mExperts.push_back(new CCLowPassTempoExpertA());
	mExperts.push_back(new CCHighPassTempoExpertA());
	mExperts.push_back(new CCTempoExpertB());
	mExperts.push_back(new CCLowPassTempoExpertB());
	mExperts.push_back(new CCHighPassTempoExpertB());

}

void CCTempoExpertA::judge()
{
	float *aCorrBufferIn = gFeatureList.rmsAutocor();
	float absPeak = gFeatureList.rmsAutocorPeak(); 	// find absPeakInd
	float threshold = gFeatureList.rmsAutocorPeakThreshold();
	unsigned bufferSize = gFeatureList.statsBufferSize();	//num cached feature items
	float peak = 0.0;
	unsigned peakIndex;
	
	// Threshold to pick peak out of noise
	for(unsigned i = 5; i < bufferSize - 5; i++){
		if (isLocalPeak(aCorrBufferIn, i) && aCorrBufferIn[i] >= threshold) {
			peak = aCorrBufferIn[i];
			peakIndex = i;
			break;
		}
	}
	
	//assume first block counts as first beat
	float sampleRate = gFeatureList.mSampleRate;
	float tempo = ((float) sampleRate / (bufferSize * peakIndex)) * 60;
	
	mVerdict = tempo;
	
	//cout << "tempoA = " << mVerdict << "\n";
}

void CCLowPassTempoExpertA::judge()
{
	float *aCorrBufferIn = gFeatureList.lowPassRMSAutocor();
	float absPeak = gFeatureList.rmsAutocorPeak(); 	// find absPeakInd
	float threshold = gFeatureList.rmsAutocorPeakThreshold();
	unsigned bufferSize = gFeatureList.statsBufferSize();	//num cached feature items
	float peak = 0.0;
	unsigned peakIndex;
	
	// Threshold to pick peak out of noise
	for(unsigned i = 5; i < bufferSize - 5; i++){
		if (isLocalPeak(aCorrBufferIn, i) && aCorrBufferIn[i] >= threshold) {
			peak = aCorrBufferIn[i];
			peakIndex = i;
			break;
		}
	}
	
	//assume first block counts as first beat
	float sampleRate = gFeatureList.mSampleRate;
	float tempo = ((float) sampleRate / (bufferSize * peakIndex)) * 60;
	
	mVerdict = tempo;
	
	//cout << "lowpasstempoA = " << mVerdict << "\n";
}

void CCHighPassTempoExpertA::judge()
{
	float *aCorrBufferIn = gFeatureList.highPassRMSAutocor();
	float absPeak = gFeatureList.rmsAutocorPeak(); 	// find absPeakInd
	float threshold = gFeatureList.rmsAutocorPeakThreshold();
	unsigned bufferSize = gFeatureList.statsBufferSize();	//num cached feature items
	float peak = 0.0;
	unsigned peakIndex;
	
	// Threshold to pick peak out of noise
	for(unsigned i = 5; i < bufferSize - 5; i++){
		if (isLocalPeak(aCorrBufferIn, i) && aCorrBufferIn[i] >= threshold) {
			peak = aCorrBufferIn[i];
			peakIndex = i;
			break;
		}
	}
	
	//assume first block counts as first beat
	float sampleRate = gFeatureList.mSampleRate;
	float tempo = ((float) sampleRate / (bufferSize * peakIndex)) * 60;
	
	mVerdict = tempo;
	
	//cout << "highpasstempoA = " << mVerdict << "\n";
}

void CCTempoExpertB::judge()
{
	float *aCorrBufferIn = gFeatureList.rmsAutocor();
	float absPeak = gFeatureList.rmsAutocorPeak(); 	// find absPeakInd
	float threshold = gFeatureList.rmsAutocorPeakThreshold();
	unsigned bufferSize = gFeatureList.statsBufferSize();	//num cached feature items
	float peak = 0.0;
	unsigned peakIndex1, peakIndex2;
	
	// Threshold to pick first peak out of noise
	for(unsigned i = 5; i < bufferSize - 5; i++){
		if (isLocalPeak(aCorrBufferIn, i) && aCorrBufferIn[i] >= threshold) {
			peak = aCorrBufferIn[i];
			peakIndex1 = i;
			break;
		}
	}
	
	// Threshold to pick second peak out of noise
	for(unsigned i = peakIndex1; i < bufferSize - peakIndex1; i++){
		if (isLocalPeak(aCorrBufferIn, i) && aCorrBufferIn[i] >= threshold) {
			peak = aCorrBufferIn[i];
			peakIndex2 = i;
			break;
		}
	}
	
	//calculate tempo from two peaks
	float sampleRate = gFeatureList.mSampleRate;
	float diff = peakIndex2 - peakIndex1;
	float tempo = ((float) sampleRate / (bufferSize * diff)) * 60;
	
	mVerdict = tempo;
	
	//cout << "tempoB = " << mVerdict << "\n";
}

void CCLowPassTempoExpertB::judge()
{
	float *aCorrBufferIn = gFeatureList.lowPassRMSAutocor();
	float absPeak = gFeatureList.rmsAutocorPeak(); 	// find absPeakInd
	float threshold = gFeatureList.rmsAutocorPeakThreshold();
	unsigned bufferSize = gFeatureList.statsBufferSize();	//num cached feature items
	float peak = 0.0;
	unsigned peakIndex1, peakIndex2;
	
	// Threshold to pick first peak out of noise
	for(unsigned i = 5; i < bufferSize - 5; i++){
		if (isLocalPeak(aCorrBufferIn, i) && aCorrBufferIn[i] >= threshold) {
			peak = aCorrBufferIn[i];
			peakIndex1 = i;
			break;
		}
	}
	
	// Threshold to pick second peak out of noise
	for(unsigned i = peakIndex1; i < bufferSize - peakIndex1; i++){
		if (isLocalPeak(aCorrBufferIn, i) && aCorrBufferIn[i] >= threshold) {
			peak = aCorrBufferIn[i];
			peakIndex2 = i;
			break;
		}
	}
	
	//calculate tempo from two peaks
	float sampleRate = gFeatureList.mSampleRate;
	float diff = peakIndex2 - peakIndex1;
	float tempo = ((float) sampleRate / (bufferSize * diff)) * 60;
	
	mVerdict = tempo;
	
	//cout << "lowpasstempoB = " << mVerdict << "\n";
}

void CCHighPassTempoExpertB::judge()
{
	float *aCorrBufferIn = gFeatureList.highPassRMSAutocor();
	float absPeak = gFeatureList.rmsAutocorPeak(); 	// find absPeakInd
	float threshold = gFeatureList.rmsAutocorPeakThreshold();
	unsigned bufferSize = gFeatureList.statsBufferSize();	//num cached feature items
	float peak = 0.0;
	unsigned peakIndex1, peakIndex2;
	
	// Threshold to pick first peak out of noise
	for(unsigned i = 5; i < bufferSize - 5; i++){
		if (isLocalPeak(aCorrBufferIn, i) && aCorrBufferIn[i] >= threshold) {
			peak = aCorrBufferIn[i];
			peakIndex1 = i;
			break;
		}
	}
	
	// Threshold to pick second peak out of noise
	for(unsigned i = peakIndex1; i < bufferSize - peakIndex1; i++){
		if (isLocalPeak(aCorrBufferIn, i) && aCorrBufferIn[i] >= threshold) {
			peak = aCorrBufferIn[i];
			peakIndex2 = i;
			break;
		}
	}
	
	//calculate tempo from two peaks
	float sampleRate = gFeatureList.mSampleRate;
	float diff = peakIndex2 - peakIndex1;
	float tempo = ((float) sampleRate / (bufferSize * diff)) * 60;
	
	mVerdict = tempo;
	
	//cout << "highpasstempoB = " << mVerdict << "\n";
}