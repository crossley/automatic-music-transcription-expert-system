/* JCFullScreenWindow */

#import <Cocoa/Cocoa.h>


@interface JCFullScreenWindow : NSWindow
{
}

- (IBAction)toggleFullScreen:(id)sender;

@end
