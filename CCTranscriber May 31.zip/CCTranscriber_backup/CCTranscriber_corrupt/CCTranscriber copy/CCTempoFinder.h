/*
 *  CCTempoFinder.h
 *  CCTranscriber
 *
 *  Created by Bebelutz on 5/7/06.
 *  Copyright 2006 __MyCompanyName__. All rights reserved.
 *
 */


#ifndef CC_TEMPO_FINDER_H			// This is in case you include this twice
#define CC_TEMPO_FINDER_H

#include "CCExpert.h"

class CCTempoFinder : public CCExpertGroup {
public:
	CCTempoFinder();							///< empty constructor
	virtual ~CCTempoFinder() { };				///< virtual destructor
										/// Clients call judge() to get the features of a buffer.
};

class CCTempoExpertA : public CCExpert {
public:
	CCTempoExpertA() : mConfidence(0.0): mExpertise(0.2) : mVerdict(0.0) { };						///< empty constructor
	virtual ~CCTempoExpertA() { };				///< virtual destructor
										/// Clients call judge() to get the features of a buffer.
	virtual void judge();		///< makes a judgment on the tempo of a block of samples.
};

class CCLowPassTempoExpertA : public CCExpert {
public:
	CCLowPassTempoExpertA() : mConfidence(0.0): mExpertise(0.3) : mVerdict(0.0){ };					///< empty constructor
	virtual ~CCLowPassTempoExpertA() { };		///< virtual destructor
										/// Clients call judge() to get the features of a buffer.
	virtual void judge();		///< makes a judgment on the tempo of a block of samples.
};

class CCHighPassTempoExpertA : public CCExpert {
public:
	CCHighPassTempoExpertA() : mConfidence(0.0): mExpertise(0.3) : mVerdict(0.0){ };				///< empty constructor
	virtual ~CCHighPassTempoExpertA() { };		///< virtual destructor
										/// Clients call judge() to get the features of a buffer.
	virtual void judge();		///< makes a judgment on the tempo of a block of samples.
};

class CCTempoExpertB : public CCExpert {
public:
	CCTempoExpertB() : mConfidence(0.0): mExpertise(0.5) : mVerdict(0.0){ };						///< empty constructor
	virtual ~CCTempoExpertB() { };				///< virtual destructor
										/// Clients call judge() to get the features of a buffer.
	virtual void judge();		///< this will be implemented in subclasses.	
};

class CCLowPassTempoExpertB : public CCExpert {
public:
	CCLowPassTempoExpertB() : mConfidence(0.0): mExpertise(0.6) : mVerdict(0.0){ };					///< empty constructor
	virtual ~CCLowPassTempoExpertB() { };		///< virtual destructor
										/// Clients call judge() to get the features of a buffer.
	virtual void judge();		///< this will be implemented in subclasses.	
};

class CCHighPassTempoExpertB : public CCExpert {
public:
	CCHighPassTempoExpertB() : mConfidence(0.0): mExpertise(0.6) : mVerdict(0.0){ };				///< empty constructor
	virtual ~CCHighPassTempoExpertB() { };		///< virtual destructor
										/// Clients call judge() to get the features of a buffer.
	virtual void judge();		///< this will be implemented in subclasses.	
};

#endif