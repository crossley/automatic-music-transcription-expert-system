/*
 *  CCFeatureItem.cpp
 *  CCTranscriber
 *
 *  Created by Bebelutz on 5/7/06.
 *  Copyright 2006 __MyCompanyName__. All rights reserved.
 *
 */

#include "CCFeatures.h"

#include "CCore.h"

#include <iostream>
using std::cout;
using std::endl;

#define TEMP_SIZE 512


CCFeatureItem::CCFeatureItem() {

//	mSampleBuffer = new float[TEMP_SIZE];


}

CCFeatureItem::~CCFeatureItem() {



}

float *CCFeatureItem::sampleBuffer() {

	return mSampleBuffer;
}

float CCFeatureItem::sampleBufferRMS() {

	return caluclateRms(mSampleBuffer, TEMP_SIZE);
}

float CCFeatureItem::autocorPeak() {

	return 0;
}

unsigned CCFeatureItem::autocorBufferSize() {

	return TEMP_SIZE;
}

void CCFeatureItem::caluclateBasicStats() {

	sampleBufferRMS();
}



#pragma mark CCFeatureList Implementation

// ******* FeatureList Implementation starts here! **************

CCFeatureList::CCFeatureList(unsigned listLength) : mNumCachedFeatureItems(listLength), mCurrentItemIndex(0) {

	mFeatureItems = new CCFeatureItem[mNumCachedFeatureItems];
	mTempOppBuffer = new float[mNumCachedFeatureItems];
	mRMSAutocor = new float[mNumCachedFeatureItems];
}

CCFeatureList::~CCFeatureList() {

	delete [] mFeatureItems;

};

CCFeatureItem *CCFeatureList::currentItem() {
	return &mFeatureItems[mCurrentItemIndex];
}


void CCFeatureList::advanceCurrentItem() {

	++mCurrentItemIndex;	
	if(mCurrentItemIndex >= mNumCachedFeatureItems) {
		// save the contents of the temp feature items into a file.
		mCurrentItemIndex = 0;
	}
	
}

float *CCFeatureList::rmsAutocor() {
	float *sampleRMSBufferPtr = mTempOppBuffer;
	// go thru the list and get the RMS values
	for(unsigned i = 0; i < mNumCachedFeatureItems; ++i)
		sampleRMSBufferPtr[i] = mFeatureItems[i].mSampleBufferRMS;
		
	// call the autocorrelation function and return a pointer to the autocorr buffer.
	caluclateAutocorrelation(sampleRMSBufferPtr, mRMSAutocor, mNumCachedFeatureItems);
	
	return mRMSAutocor;

}


float CCFeatureList::rmsAutocorPeak() {
		
	// call the autocorrelation function and return a pointer to the autocorr buffer.
	unsigned index = findAbsPeakIndex(mRMSAutocor, mNumCachedFeatureItems);
	mRMSAutocorPeak = mRMSAutocor[index];
	
	return mRMSAutocorPeak;

}
