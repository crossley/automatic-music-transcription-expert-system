#import "CControllerAndBridge.h"

#include "CCore.h"

@implementation CControllerAndBridge



- (BOOL) application:(NSApplication*)theApplication openFile:(NSString*)filename
{
	//Let's remember the file for later
	mFilePath = [filename retain];
	return YES;
}


- (void) applicationDidFinishLaunching:(NSNotification*)aNotification 
{

	NSOpenPanel *openPanel;
	//If no composition file was dropped on the application's icon, we need to ask the user for one
	if(mFilePath == nil) {
		openPanel = [NSOpenPanel openPanel];
		[openPanel setAllowsMultipleSelection:NO];
		[openPanel setCanChooseDirectories:NO];
		[openPanel setCanChooseFiles:YES];
		if([openPanel runModalForDirectory:nil file:nil types:[NSArray arrayWithObject:@"aif"]] != NSOKButton) {
			NSLog(@"No file specified");
			[NSApp terminate:nil];
		}
		mFilePath = [[[openPanel filenames] objectAtIndex:0] retain];
	}

	// open file
	inFile = sf_open([mFilePath cStringUsingEncoding: [NSString defaultCStringEncoding]], SFM_READ, &soundFileInfo);
	if (soundFileInfo.channels != 1) {
		NSLog(@"Error: I can only process mono files\n");
		[NSApp terminate:nil];
	}
	
	// Allocate memory for the complete file (hopeing it's not too big)
	float *songBufferPtr = (float *)calloc(soundFileInfo.frames, sizeof(float));

	sf_read_float(inFile, songBufferPtr, soundFileInfo.frames);
	
	musicTranscriber = new CCTranscriptionEngine(soundFileInfo.frames, songBufferPtr);	
	musicTranscriber->judge();			
	
	[self toggleFullScreen:self];
	
}

- (void) applicationWillTerminate:(NSNotification*)aNotification 
{

	sf_close(inFile);

}


- (IBAction)toggleFullScreen:(id)sender
{
	NSWindow* mainWindow = [NSApp mainWindow];

    //This next line pulls the window up to the front on top of other system windows.  This is how the Clock app behaves;
    //generally you wouldn't do this for windows unless you really wanted them to float above everything.
    [mainWindow setLevel: NSScreenSaverWindowLevel];
	
    [mainWindow setBackgroundColor:[NSColor blackColor]];

    // make sure the window has no shadow
    [mainWindow setHasShadow:NO];
	
	[NSMenu setMenuBarVisible:NO];
	
    // Resize the window to full screen   
    NSRect screenFrame = [NSWindow frameRectForContentRect:[[NSScreen mainScreen] frame] styleMask:NSTitledWindowMask];
    [mainWindow setFrame:screenFrame display:YES animate:YES];


}


@end
