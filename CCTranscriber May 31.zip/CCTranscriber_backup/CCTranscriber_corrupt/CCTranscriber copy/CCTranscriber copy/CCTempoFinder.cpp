/*
 *  CCTempoFinder.cpp
 *  CCTranscriber
 *
 *  Created by Bebelutz on 5/7/06.
 *  Copyright 2006 __MyCompanyName__. All rights reserved.
 *
 */

#include "CCTempoFinder.h"
#include "CCore.h"

#include <iostream>
using std::cout;
using std::endl;

//Constructor
CCTempoFinder::CCTempoFinder()
{
	
	mExperts.push_back(new CCTempoExpertA());

}

void CCTempoExpertA::judge()
{
	float *aCorrBufferIn = gFeatureList.rmsAutocor();
	float absPeak = gFeatureList.rmsAutocorPeak(); 	// find absPeakInd
	unsigned bufferSize = gFeatureList.statsBufferSize();
	float peak = 0.0;
	unsigned peakIndex;
	
	//choose an arbitrary (for now) threshold to pick peaks out of noise
	for(unsigned i = 5; i < bufferSize - 5; i++){
		if (isLocalPeak(aCorrBufferIn, i) && aCorrBufferIn[i] >= 0.9 * absPeak) {
			peak = aCorrBufferIn[i];
			peakIndex = i;
			break;
		}
	}
	
	//assume first window counts as first beat
	float sampleRate = gFeatureList.mSampleRate;
	float tempo = ((float) sampleRate / (bufferSize * peakIndex)) * 60;
	
	mVerdict = tempo;
	cout << absPeak << endl;
	
}

//determines if a sample at index is larger than its adjacent neighbors
bool CCTempoExpertA::isLocalPeak(float *autocorBufferIn, unsigned index)
{
	unsigned i = index;
	
	if((autocorBufferIn[i] > autocorBufferIn[i-1]) && (autocorBufferIn[i] > autocorBufferIn[i+1]))
		return true;
	else
		return false;
}