/*
 *  CCTranscriptionEngine.cpp
 *  CCTranscriber
 *
 *  Created by Bebelutz on 5/7/06.
 *  Copyright 2006 __MyCompanyName__. All rights reserved.
 *
 */

#include "CCTranscriptionEngine.h"

#include "CCTempoFinder.h"

#include "CCore.h"

#include <iostream>
using std::cout;
using std::endl;

//Constructor
CCTranscriptionEngine::CCTranscriptionEngine(unsigned numSamples, float *bufferOfSamples) : mNumSamples(numSamples), mSampleBufferPtr(bufferOfSamples) {
	
	mExperts.push_back(new CCTempoFinder());

}


void CCTranscriptionEngine::judge()
{
	float *sampleBufferPtr = mSampleBufferPtr;
	int samplesLeft = (int)mNumSamples;
	unsigned increment = 512;
	
	while (samplesLeft > 0) {			
		gFeatureList.currentItem()->setSampleBuffer(sampleBufferPtr); // Set the pointer of the current feature item to look at the buffer of samples.
		gFeatureList.currentItem()->caluclateBasicStats(); // Precaluclate some data.

		CCExpertGroup::judge(); // Call the superclass version of this function, so it calls judge on each of my children.

		gFeatureList.advanceCurrentItem();

		if(samplesLeft < increment)
			increment = samplesLeft;

		sampleBufferPtr += increment;
		samplesLeft -= increment;
	} // end of while loop
		
}