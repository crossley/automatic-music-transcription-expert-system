/*
 *  CCTempoFinder.h
 *  CCTranscriber
 *
 *  Created by Bebelutz on 5/7/06.
 *  Copyright 2006 __MyCompanyName__. All rights reserved.
 *
 */


#ifndef CC_TEMPO_FINDER_H			// This is in case you include this twice
#define CC_TEMPO_FINDER_H

#include "CCExpert.h"

class CCTempoFinder : public CCExpertGroup {
public:
	CCTempoFinder();						///< empty constructor
	virtual ~CCTempoFinder() { };				///< virtual destructor
										/// Clients call judge() to get the features of a buffer.
};

class CCTempoExpertA : public CCExpert {
public:
	CCTempoExpertA() { };						///< empty constructor
	virtual ~CCTempoExpertA() { };				///< virtual destructor
										/// Clients call judge() to get the features of a buffer.
	virtual void judge();		///< this will be implemented in subclasses.
	
private:
	unsigned findAbsPeakInd(float * autocorBufferIn, unsigned bufferSize);
	bool isLocalPeak(float * autocorBufferIn, unsigned index);
	
};


#endif