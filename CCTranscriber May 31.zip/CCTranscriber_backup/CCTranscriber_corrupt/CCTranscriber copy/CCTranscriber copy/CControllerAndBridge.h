/* controllerAndBridge */

#import <Cocoa/Cocoa.h>

#include "sndfile.h"

#include "CCTranscriptionEngine.h"

@interface CControllerAndBridge : NSObject
{
	CCTranscriptionEngine *musicTranscriber;
	NSString *mFilePath;
	SNDFILE *inFile;
	SF_INFO soundFileInfo;
	
}

- (IBAction)toggleFullScreen:(id)sender;

@end
