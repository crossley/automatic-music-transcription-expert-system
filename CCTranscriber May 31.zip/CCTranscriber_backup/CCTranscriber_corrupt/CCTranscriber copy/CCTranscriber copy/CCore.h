/*
 *  CCCore.h
 *  CCTranscriber
 *
 *  Created by Bebelutz on 5/7/06.
 *  Copyright 2006 __MyCompanyName__. All rights reserved.
 *
 */

#ifndef CC_CORE_H			// This is in case you include this twice
#define CC_CORE_H

#include <math.h>

#include "CCFeatures.h"


CCFeatureList gFeatureList;

float caluclateRms(float *sampleBufferPtr, unsigned bufferSize)
{
	float sum = 0.0, samp;
	
	// compute the RMS value of the buffer
    for(unsigned i = 0; i < bufferSize; i++ ) {
		samp = sampleBufferPtr[i];
		sum += samp * samp;
    }
	
	return sqrt(sum / bufferSize);
}


void caluclateAutocorrelation(float *rmsBufferPtr, float *correlationBufferPtr, unsigned bufferSize)
{
	float sum;
	// AUTOCORR (original source from libtsp P. Kabal)
	for (unsigned i = 0; i < bufferSize; ++i) {
		sum = 0.0;
		for (unsigned j = 0; j < bufferSize - i; ++j) {
			sum += rmsBufferPtr[j] * rmsBufferPtr[i + j];
		}
		
		correlationBufferPtr[i] = sum;
	}

}


unsigned findAbsPeakIndex(float *bufferIn, unsigned bufferSize)
{
	float absPeak = 0;
	unsigned absPeakIndex = 0;
	for (unsigned i = 5; i < bufferSize - 5; i++) {
		// method 2: find absolute peak value
		if (bufferIn[i] > absPeak) {
			absPeak = bufferIn[i];
			absPeakIndex = i;
		}
	}
	
	return absPeakIndex;
}


#endif