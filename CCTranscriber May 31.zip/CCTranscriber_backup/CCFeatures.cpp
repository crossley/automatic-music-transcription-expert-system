/*
 *  CCFeatureItem.cpp
 *  CCTranscriber
 *
 *  Created by Bebelutz on 5/7/06.
 *  Copyright 2006 __MyCompanyName__. All rights reserved.
 *
 */

#include "CCFeatures.h"

#include "CCore.h"

#include <iostream>
using std::cout;
using std::endl;

#define TEMP_SIZE 512

#pragma mark CCFeatureItem Implementation

CCFeatureItem::CCFeatureItem() {

//	mSampleBuffer = new float[TEMP_SIZE];

	//allocate some memory for filter buffers -- don't want hard code! --
	mLowPassSampleBuffer = new float[TEMP_SIZE];
	mHighPassSampleBuffer = new float[TEMP_SIZE];
	mFourierSpectrumBuffer = new float[TEMP_SIZE];
	
	mFFTAnalyzer = new CCFFTer;

	//initialize filter history -- is initalizing these to zero a good idea? --
		
	//I dont know why these initializations are causing compile errors
	
//	mLowPassPrevIn = {0.0, 0.0, 0.0, 0.0};
//	mLowPassPrevOut = {0.0, 0.0, 0.0, 0.0};
//	mHighPassPrevIn = {0.0, 0.0, 0.0, 0.0};
//	mHighPassPrevOut = {0.0, 0.0, 0.0, 0.0};

}

CCFeatureItem::~CCFeatureItem() {

	delete mFFTAnalyzer;

}

// NOTE: ALL THE METHODS BELOW SHOULD BE AWARE IF THEY WERE CALLED, SO DO NOT 
// PERFORM THE CALCULATIONS AGAIN. FOR NOW, THE METHOD BELOW PRECALCULATES EVERYTHING,
// SO THE OTHER METHODS ASSUME IT'S ALREADY DONE. THIS SHOULD BE FIXED IN THE FUTURE :-) Jorge C. 
void CCFeatureItem::calculateBasicStats() {
	
	//why aren't these voids?
	lowPassSampleBuffer();
	highPassSampleBuffer();
	sampleBufferRMS();
	lowPassSampleBufferRMS();
	highPassSampleBufferRMS();
	mFFTAnalyzer->calculateFFT(mSampleBuffer, mFourierSpectrumBuffer);
	
}

unsigned CCFeatureItem::sampleBufferSize() {
	return mSampleBufferSize;
}

void CCFeatureItem::setSampleBuffer(float *sampleBuffer) { 
	mSampleBuffer = sampleBuffer;
}

float *CCFeatureItem::sampleBuffer() {
	return mSampleBuffer;
}


float* CCFeatureItem::lowPassSampleBuffer() {
	float* inputBuffer = mSampleBuffer;
	float* filteredBuffer = mLowPassSampleBuffer;
	float* prevIn = mLowPassPrevIn;
	float* prevOut = mLowPassPrevOut;
	lowPassFilter(/*this should be a slider*/ TEMP_SIZE, inputBuffer, filteredBuffer, prevIn, prevOut);
	
	return mLowPassSampleBuffer;
}

float* CCFeatureItem::highPassSampleBuffer() {
	float* inputBuffer = mSampleBuffer;
	float* filteredBuffer = mHighPassSampleBuffer;
	float* prevIn = mHighPassPrevIn;
	float* prevOut = mHighPassPrevOut;
	highPassFilter(/*this should be a slider*/ TEMP_SIZE, inputBuffer, filteredBuffer, prevIn, prevOut);
	
	return mHighPassSampleBuffer;
}

float* CCFeatureItem::fourierSpectrumBuffer() {
//	highPassFilter(/*this should be a slider*/ TEMP_SIZE, inputBuffer, filteredBuffer, prevIn, prevOut);
	
	return mFourierSpectrumBuffer;
}

float CCFeatureItem::sampleBufferRMS() {

	mSampleBufferRMS = caluclateRms(mSampleBuffer, TEMP_SIZE);
	return mSampleBufferRMS;
}

float CCFeatureItem::lowPassSampleBufferRMS() {

	mLowPassSampleBufferRMS = caluclateRms(mLowPassSampleBuffer, TEMP_SIZE);
	return mLowPassSampleBufferRMS;
}

float CCFeatureItem::highPassSampleBufferRMS() {

	mHighPassSampleBufferRMS = caluclateRms(mHighPassSampleBuffer, TEMP_SIZE);
	return mHighPassSampleBufferRMS;

}

float CCFeatureItem::spectrumPeak() {

	return 0;
}

unsigned CCFeatureItem::autocorBufferSize() {

	return TEMP_SIZE;
}




#pragma mark CCFeatureList Implementation

// ******* FeatureList Implementation starts here! **************

CCFeatureList::CCFeatureList(unsigned listLength) : mNumCachedFeatureItems(listLength), mCurrentItemIndex(0), mSampleRate(44100) {

	mFeatureItems = new CCFeatureItem[mNumCachedFeatureItems];
	mTempOppBuffer = new float[mNumCachedFeatureItems];
	mRMSAutocor = new float[mNumCachedFeatureItems];
	mLowPassRMSAutocor = new float[mNumCachedFeatureItems];
	mHighPassRMSAutocor = new float[mNumCachedFeatureItems];
}

CCFeatureList::~CCFeatureList() {

	delete [] mFeatureItems;
	delete [] mTempOppBuffer;
	delete [] mRMSAutocor;
	delete [] mLowPassRMSAutocor;
	delete [] mHighPassRMSAutocor;

};

CCFeatureItem *CCFeatureList::currentItem() {
	return &mFeatureItems[mCurrentItemIndex];
}


void CCFeatureList::advanceCurrentItem() {

	++mCurrentItemIndex;	
	if(mCurrentItemIndex >= mNumCachedFeatureItems) {
		// TODO: save the contents of the temp feature items into a file.
		mCurrentItemIndex = 0;
	}
	
}

// *** All stats calculations on the list start here! *** //

float *CCFeatureList::rmsAutocor() {
	float *sampleRMSBufferPtr = mTempOppBuffer;
	// go thru the list and get the RMS values
	for(unsigned i = 0; i < mNumCachedFeatureItems; ++i) {
		sampleRMSBufferPtr[i] = mFeatureItems[i].mSampleBufferRMS;

	}
	// call the autocorrelation function and return a pointer to the autocorr buffer.
	caluclateAutocorrelation(sampleRMSBufferPtr, mRMSAutocor, mNumCachedFeatureItems);
	
	return mRMSAutocor;

}

float *CCFeatureList::lowPassRMSAutocor() {
	float *lowPassSampleRMSBufferPtr = mTempOppBuffer;
	// go thru the list and get the RMS values
	for(unsigned i = 0; i < mNumCachedFeatureItems; ++i) {
		lowPassSampleRMSBufferPtr[i] = mFeatureItems[i].mLowPassSampleBufferRMS;
	}
	// call the autocorrelation function and return a pointer to the autocorr buffer.
	caluclateAutocorrelation(lowPassSampleRMSBufferPtr, mLowPassRMSAutocor, mNumCachedFeatureItems);
	
	return mLowPassRMSAutocor;
}

float *CCFeatureList::highPassRMSAutocor() {
	float *highPassSampleRMSBufferPtr = mTempOppBuffer;
	// go thru the list and get the RMS values
	for(unsigned i = 0; i < mNumCachedFeatureItems; ++i) {
		highPassSampleRMSBufferPtr[i] = mFeatureItems[i].mHighPassSampleBufferRMS;
	}
	// call the autocorrelation function and return a pointer to the autocorr buffer.
	caluclateAutocorrelation(highPassSampleRMSBufferPtr, mHighPassRMSAutocor, mNumCachedFeatureItems);
	
	return mHighPassRMSAutocor;
}


float CCFeatureList::rmsAutocorPeak() {
		
	// call the autocorrelation function and return a pointer to the autocorr buffer.
	unsigned index = findAbsPeakIndex(mRMSAutocor, mNumCachedFeatureItems);
	mRMSAutocorPeak = mRMSAutocor[index];
	
	return mRMSAutocorPeak;

}

float CCFeatureList::lowPassRMSAutocorPeak() {
	
	// call the autocorrelation function and return a pointer to the autocorr buffer.
	unsigned index = findAbsPeakIndex(mLowPassRMSAutocor, mNumCachedFeatureItems);
	mLowPassRMSAutocorPeak = mLowPassRMSAutocor[index];
	
	return mLowPassRMSAutocorPeak;
	
}

float CCFeatureList::highPassRMSAutocorPeak() {

	// call the autocorrelation function and return a pointer to the autocorr buffer.
	unsigned index = findAbsPeakIndex(mHighPassRMSAutocor, mNumCachedFeatureItems);
	mHighPassRMSAutocorPeak = mHighPassRMSAutocor[index];
	
	return mLowPassRMSAutocorPeak;
	
}

float CCFeatureList::rmsAutocorPeakThreshold() {

	float STD = calculateSTD(mRMSAutocor, mNumCachedFeatureItems);
	float threshold = mRMSAutocorPeak - 2.0 * STD;
	
	mRMSAutocorPeakThreshold = threshold;
	
	return mRMSAutocorPeakThreshold;

}

float CCFeatureList::lowPassRMSAutocorPeakThreshold() {

	float STD = calculateSTD(mLowPassRMSAutocor, mNumCachedFeatureItems);
	float threshold = mLowPassRMSAutocorPeak - 2.0 * STD;
	
	mLowPassRMSAutocorPeakThreshold = threshold;
	
	return mLowPassRMSAutocorPeakThreshold;

}

float CCFeatureList::highPassRMSAutocorPeakThreshold() {

	float STD = calculateSTD(mHighPassRMSAutocor, mNumCachedFeatureItems);
	float threshold = mHighPassRMSAutocorPeak - 2.0 * STD;
	
	mHighPassRMSAutocorPeakThreshold = threshold;
	
	return mHighPassRMSAutocorPeakThreshold;

}
