/*
 *  CCFFTer.cpp
 *  CCTranscriber
 *
 *  Created by Bebelutz on 5/12/06.
 *  Copyright 2006 Jorge Castellanos. All rights reserved.
 *
 */

#include "CCFFTer.h"

#include <string.h>
#include <math.h>


#include <iostream>
using std::cout;
using std::endl;


// Set up the FFTer
CCFFTer::CCFFTer( unsigned windowSize) : mWindowSize(windowSize)
{	
	mSpectrum = (fftwf_complex*) fftwf_malloc( sizeof(fftwf_complex ) * mWindowSize * 2);
	mSampleBuffer = (float *) fftwf_malloc(sizeof(float) * mWindowSize * 2);
	
	mFFTPlan = fftwf_plan_dft_r2c_1d(mWindowSize * 2, mSampleBuffer, mSpectrum, FFTW_MEASURE); // Create the FFT plan
}

// Destructor
CCFFTer::~CCFFTer( ) {
	fftwf_destroy_plan(mFFTPlan);
	fftwf_free( mSpectrum );
}

void CCFFTer::calculateFFT(float *inputSamples, float *outputSpectra) {
	
	memset(mSampleBuffer, 0, mWindowSize * 2 * sizeof(float));
	memcpy(mSampleBuffer, inputSamples, mWindowSize * sizeof(float)); // Copy the data

	fftwf_execute( mFFTPlan );

	fftwf_complex *spectrumPtr = mSpectrum;
	float normFactor = 1.0 / sqrt( static_cast<double>( mWindowSize ) );

	for (unsigned i = 1; i <= mWindowSize + 1; i++, spectrumPtr++) {
		outputSpectra[i] = hypot(*(spectrumPtr)[0], *(spectrumPtr)[1]) * normFactor;//
#ifdef DEBUG_MESSAGES
		cout << outputSpectra[i] << endl;
#endif
	}

}

