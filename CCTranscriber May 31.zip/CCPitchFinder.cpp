/*
 *  CCTempoFinder.cpp
 *  CCTranscriber
 *
 *  Created by Bebelutz on 5/7/06.
 *  Copyright 2006 __MyCompanyName__. All rights reserved.
 *
 */

#include "CCPitchFinder.h"
#include "CCFeatures.h"
#include "CCore.h"

extern CCFeatureList gFeatureList;

#include <iostream>
using std::cout;
using std::endl;

#pragma mark -- constructors --

//Constructor
CCPitchFinder::CCPitchFinder()
{
	
	mExperts.push_back(new CCPitchExpertA());
	mExperts.push_back(new CCZeroCrossingPitchExpert());
	mExperts.push_back(new CCHarmonicProductPitchExpert());
	
	mVerdictHistory = new float[mExperts.size()];
	mConfidenceHistory = new float[mExperts.size()];
	mExpertiseHistory = new float[mExperts.size()];

}

CCPitchExpertA::CCPitchExpertA()
{
	mExpertise = 0.5;
}

CCZeroCrossingPitchExpert::CCZeroCrossingPitchExpert()
{
	mExpertise = 0.5;
}

CCHarmonicProductPitchExpert::CCHarmonicProductPitchExpert()
{
	mExpertise = 0.5;
}

#pragma mark -- CCPitchFinder --

void CCPitchFinder::judge() 
{

	//first loop thru experts to gather individual verdicts
	CCExpertGroup::judge();
	
	//now judge the evidence returned by experts
	int i = 0; int usefulVerdicts = mExperts.size();
	list<CCAbstractExpert *>::iterator expert;
	for (expert = mExperts.begin(); expert != mExperts.end(); expert++, i++)
	{

		mVerdictHistory[i] = (*expert)->verdict();
		mConfidenceHistory[i] = (*expert)->confidence();
		mExpertiseHistory[i] = (*expert)->expertise();
	}
	
	for(i = 0; i < mExperts.size(); i++)
	{
		if(mVerdictHistory[i] == -1)	// if block clearly didn't receive fair trial (see review())
		{
			mVerdictHistory[i] == 0;	// the verdict won't be considered
			usefulVerdicts--; 
		}
	}

}

void CCPitchFinder::review() {}

#pragma mark -- CCPitchExpertA judge --

void CCPitchExpertA::judge()
{
	const float *spectrumBufferPtr = gFeatureList.currentItem()->fourierSpectrumBuffer();
	unsigned bufferSize = gFeatureList.currentItem()->sampleBufferSize();
	
	// find the highest peak in the buffer
	unsigned peakIndex = findAbsPeakIndex(spectrumBufferPtr, bufferSize, 1);
//	peak = spectrumBufferPtr[index];
	
	float peakFrequency = (float) gFeatureList.mSampleRate * ((float)peakIndex - 1) * 0.5 / (float)bufferSize;
	
	mVerdict = peakFrequency;
	
//	cout << "CCPitchExpertA veredict: " << mVerdict << endl;
}

#pragma mark -- CCZeroCrossingPitchExpert judge --

void CCZeroCrossingPitchExpert::judge()
{
	const float *sampleBufferPtr = gFeatureList.currentItem()->sampleBuffer();
	unsigned bufferSize = gFeatureList.currentItem()->sampleBufferSize();
	unsigned zerosCount = 0;
	float previousSample = *sampleBufferPtr++;
	float currentSample;
	for (unsigned i = 1; i < bufferSize; i++ ) {
		currentSample = *sampleBufferPtr++;
		if ((previousSample <= 0.0) && (currentSample > 0.0))
			zerosCount++;
		previousSample = currentSample;
	}
	
	float sampleRate = gFeatureList.mSampleRate;
	
	float theFrequency = zerosCount * (sampleRate / bufferSize);			// FIX THIS

	mVerdict = theFrequency;
//	cout << "CCZeroCrossingPitchExpert veredict: " << mVerdict << endl;
	
}

#pragma mark -- CCHarmonicProductPitchExpert judge --

void CCHarmonicProductPitchExpert::judge()
{
	const float *spectrumBufferPtr = gFeatureList.currentItem()->fourierSpectrumBuffer();
	unsigned bufferSize = gFeatureList.currentItem()->sampleBufferSize();
	float harmonicProductSpectrum[bufferSize];
	unsigned index;
	
	memcpy(harmonicProductSpectrum, spectrumBufferPtr, bufferSize * sizeof(float));

	// i starts at two si it increments the "decimator" (index) by two in the first round
	// the increment by one is already done by the memcpy above
	for (unsigned i = 2; i <= 5; i++) {
		index = 0;
		// loop through spectrum data summinbg every n'th value into the copied spectrum
		for (unsigned j = 0; index < bufferSize; j++, index+=i)
			harmonicProductSpectrum[j] *= spectrumBufferPtr[index];
	}

	// find the highest peak in the buffer
	unsigned peakIndex = findAbsPeakIndex(harmonicProductSpectrum, bufferSize, 1);

	float sampleRate = gFeatureList.mSampleRate;
	
	float peakFrequency = (float)sampleRate * ((float)peakIndex - 1) * 0.5 / (float)bufferSize;
	
	mVerdict = peakFrequency;

//	cout << "CCHarmonicProductPitchExpert veredict: " << mVerdict << endl;
	
}

#pragma mark -- CCPitchExpertA review --

void CCPitchExpertA::review() {}

#pragma mark -- CCZeroCrossingPitchExpert review --

void CCZeroCrossingPitchExpert::review() {}

#pragma mark -- CCHarmonicProductPitchExpert review --

void CCHarmonicProductPitchExpert::review() {}