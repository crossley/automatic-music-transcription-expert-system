/*
 *  CCGlobals.h
 *  CCTranscriber
 *
 *  Created by Bebelutz on 5/15/06.
 *  Copyright 2006 __MyCompanyName__. All rights reserved.
 *
 */


#ifndef CC_GLOBALS_H			// This is in case you include this twice
#define CC_GLOBALS_H


#include "CCFeatures.h"


CCFeatureList gFeatureList;


#endif
