/*
 *  CCFeatureItem.cpp
 *  CCTranscriber
 *
 *  Created by Bebelutz on 5/7/06.
 *  Copyright 2006 __MyCompanyName__. All rights reserved.
 *
 */

#include "CCFeatures.h"

#include "CCore.h"
#include "CCFilter.h"

#include <iostream>
using std::cout;
using std::endl;

#define TEMP_SIZE 512

#pragma mark CCFeatureItem Implementation

CCFeatureItem::CCFeatureItem() : mSampleBufferSize(TEMP_SIZE) {

//	mSampleBuffer = new float[TEMP_SIZE];

	//allocate some memory for filter buffers -- don't want hard code! --
	mLowPassSampleBuffer = new float[TEMP_SIZE];
	mHighPassSampleBuffer = new float[TEMP_SIZE];
	mFourierSpectrumBuffer = new float[TEMP_SIZE];		//doesn't CCFFTer allocate its own memory?
	mLogFourierSpectrumBuffer = new float[TEMP_SIZE];	//so why do it here?
	mCepstrumBuffer = new float[TEMP_SIZE];
	
	mFFTAnalyzer = new CCFFTer;
	mCepstrumAnalyzer = new CCFFTer;

	//initialize filter history -- is initalizing these to zero a good idea? --
		
	//I dont know why these initializations are causing compile errors
	
//	mLowPassPrevIn = {0.0, 0.0, 0.0, 0.0};
//	mLowPassPrevOut = {0.0, 0.0, 0.0, 0.0};
//	mHighPassPrevIn = {0.0, 0.0, 0.0, 0.0};
//	mHighPassPrevOut = {0.0, 0.0, 0.0, 0.0};

}

CCFeatureItem::~CCFeatureItem() {

	delete mFFTAnalyzer;

}

// NOTE: ALL THE METHODS BELOW SHOULD BE AWARE IF THEY WERE CALLED, SO DO NOT 
// PERFORM THE CALCULATIONS AGAIN. FOR NOW, THE METHOD BELOW PRECALCULATES EVERYTHING,
// SO THE OTHER METHODS ASSUME IT'S ALREADY DONE. THIS SHOULD BE FIXED IN THE FUTURE :-) Jorge C. 
void CCFeatureItem::calculateBasicStats() {
	
	lowPassSampleBuffer();
	highPassSampleBuffer();
	sampleBufferRMS();
	lowPassSampleBufferRMS();
	highPassSampleBufferRMS();
	mFFTAnalyzer->calculateFFT(mSampleBuffer, mFourierSpectrumBuffer);
	logFourierSpectrumBuffer();
	mCepstrumAnalyzer->calculateFFT(mLogFourierSpectrumBuffer, mCepstrumBuffer);
	
	for(int i = 0; i < TEMP_SIZE; i++)
	{
		cout << mLogFourierSpectrumBuffer[i] << " " << mCepstrumBuffer[i] << "\n";
	}
	
}

unsigned CCFeatureItem::sampleBufferSize() {
	return mSampleBufferSize;
}

void CCFeatureItem::setSampleBuffer(float *sampleBuffer) { 
	mSampleBuffer = sampleBuffer;
}

float *CCFeatureItem::sampleBuffer() {
	return mSampleBuffer;
}


float* CCFeatureItem::lowPassSampleBuffer() {
	float* inputBuffer = mSampleBuffer;
	float* filteredBuffer = mLowPassSampleBuffer;
	float* prevIn = mLowPassPrevIn;
	float* prevOut = mLowPassPrevOut;
	lowPassFilter(TEMP_SIZE, inputBuffer, filteredBuffer, prevIn, prevOut);
	
	return mLowPassSampleBuffer;
}

float* CCFeatureItem::highPassSampleBuffer() {
	float* inputBuffer = mSampleBuffer;
	float* filteredBuffer = mHighPassSampleBuffer;
	float* prevIn = mHighPassPrevIn;
	float* prevOut = mHighPassPrevOut;
	highPassFilter(TEMP_SIZE, inputBuffer, filteredBuffer, prevIn, prevOut);
	
	return mHighPassSampleBuffer;
}

float* CCFeatureItem::fourierSpectrumBuffer() {	
	return mFourierSpectrumBuffer;
}

float* CCFeatureItem::logFourierSpectrumBuffer() {
	logMagnitude(mFourierSpectrumBuffer, mLogFourierSpectrumBuffer, TEMP_SIZE, 10);
}

float* CCFeatureItem::cepstrumBuffer() {
	return mCepstrumBuffer;
}

float CCFeatureItem::sampleBufferRMS() {

	mSampleBufferRMS = caluclateRms(mSampleBuffer, TEMP_SIZE);
	return mSampleBufferRMS;
}

float CCFeatureItem::lowPassSampleBufferRMS() {

	mLowPassSampleBufferRMS = caluclateRms(mLowPassSampleBuffer, TEMP_SIZE);
	return mLowPassSampleBufferRMS;
}

float CCFeatureItem::highPassSampleBufferRMS() {

	mHighPassSampleBufferRMS = caluclateRms(mHighPassSampleBuffer, TEMP_SIZE);
	return mHighPassSampleBufferRMS;

}

float CCFeatureItem::spectrumPeak() {

	return 0;
}

unsigned CCFeatureItem::autocorBufferSize() {

	return TEMP_SIZE;
}




#pragma mark CCFeatureList Implementation

// ******* FeatureList Implementation starts here! **************

CCFeatureList::CCFeatureList(unsigned listLength) : mNumCachedFeatureItems(listLength), mCurrentItemIndex(0), mSampleRate(44100) {

	mFeatureItems = new CCFeatureItem[mNumCachedFeatureItems];
	mTempOppBuffer = new float[mNumCachedFeatureItems];
	mRMSAutocor = new float[mNumCachedFeatureItems];
	mLowPassRMSAutocor = new float[mNumCachedFeatureItems];
	mHighPassRMSAutocor = new float[mNumCachedFeatureItems];
}

CCFeatureList::~CCFeatureList() {

	delete [] mFeatureItems;
	delete [] mTempOppBuffer;
	delete [] mRMSAutocor;
	delete [] mLowPassRMSAutocor;
	delete [] mHighPassRMSAutocor;

};

void CCFeatureList::calculateBasicStats(){}

CCFeatureItem *CCFeatureList::currentItem() {
	return &mFeatureItems[mCurrentItemIndex];
}


void CCFeatureList::advanceCurrentItem() {

	++mCurrentItemIndex;	
	if(mCurrentItemIndex >= mNumCachedFeatureItems) {
		// TODO: save the contents of the temp feature items into a file.
		mCurrentItemIndex = 0;
	}
	
}

// *** All stats calculations on the list start here! *** //

float *CCFeatureList::rmsAutocor() {
	float *sampleRMSBufferPtr = mTempOppBuffer;
	unsigned index = mCurrentItemIndex;
	// go thru the list and get the RMS values
	for(unsigned i = 0; i < mNumCachedFeatureItems; ++i, --index) {
		sampleRMSBufferPtr[i] = mFeatureItems[index].mSampleBufferRMS;
		if(index == 0)
			index = mNumCachedFeatureItems;
	}
	
	// call the autocorrelation function and return a pointer to the autocorr buffer.
	caluclateAutocorrelation(sampleRMSBufferPtr, mRMSAutocor, mNumCachedFeatureItems);
	
	return mRMSAutocor;

}

float *CCFeatureList::lowPassRMSAutocor() {
	float *lowPassSampleRMSBufferPtr = mTempOppBuffer;
	unsigned index = mCurrentItemIndex;

	// go thru the list and get the RMS values
	for(unsigned i = 0; i < mNumCachedFeatureItems; ++i, --index) {
		lowPassSampleRMSBufferPtr[i] = mFeatureItems[index].mLowPassSampleBufferRMS;
		if(index == 0)
			index = mNumCachedFeatureItems;
	}
	// call the autocorrelation function and return a pointer to the autocorr buffer.
	caluclateAutocorrelation(lowPassSampleRMSBufferPtr, mLowPassRMSAutocor, mNumCachedFeatureItems);
	
	return mLowPassRMSAutocor;
}

float *CCFeatureList::highPassRMSAutocor() {
	float *highPassSampleRMSBufferPtr = mTempOppBuffer;
	unsigned index = mCurrentItemIndex;
	
	// go thru the list and get the RMS values
	for(unsigned i = 0; i < mNumCachedFeatureItems; ++i, --index) {
		highPassSampleRMSBufferPtr[i] = mFeatureItems[index].mHighPassSampleBufferRMS;
		if(index == 0)
			index = mNumCachedFeatureItems;
	}
	// call the autocorrelation function and return a pointer to the autocorr buffer.
	caluclateAutocorrelation(highPassSampleRMSBufferPtr, mHighPassRMSAutocor, mNumCachedFeatureItems);
	
	return mHighPassRMSAutocor;
}


float CCFeatureList::rmsAutocorPeak() {
		
	// call the autocorrelation function and return a pointer to the autocorr buffer.
	unsigned index = findAbsPeakIndex(mRMSAutocor, mNumCachedFeatureItems, 5);
	mRMSAutocorPeak = mRMSAutocor[index];
	
	return mRMSAutocorPeak;

}

float CCFeatureList::lowPassRMSAutocorPeak() {
	
	// call the autocorrelation function and return a pointer to the autocorr buffer.
	unsigned index = findAbsPeakIndex(mLowPassRMSAutocor, mNumCachedFeatureItems, 5);
	mLowPassRMSAutocorPeak = mLowPassRMSAutocor[index];
	
	return mLowPassRMSAutocorPeak;
	
}

float CCFeatureList::highPassRMSAutocorPeak() {

	// call the autocorrelation function and return a pointer to the autocorr buffer.
	unsigned index = findAbsPeakIndex(mHighPassRMSAutocor, mNumCachedFeatureItems, 5);
	mHighPassRMSAutocorPeak = mHighPassRMSAutocor[index];
	
	return mLowPassRMSAutocorPeak;
	
}

float CCFeatureList::rmsAutocorPeakThreshold() {

	float STD = calculateSTD(mRMSAutocor, mNumCachedFeatureItems);
	
	mRMSAutocorPeak = rmsAutocorPeak();		// Think about putting this kind of stuff in calculateBasicStats...
	
	float threshold = mRMSAutocorPeak - 2.0 * STD;
	
	mRMSAutocorPeakThreshold = threshold;
	
//	cout << "\n" << "Autocor STD = " << STD << "\n";
//	cout << "mRMSAutocorPeak = " << mRMSAutocorPeak << "\n";
//	cout << "threshold = " << threshold << "\n";
	
	return mRMSAutocorPeakThreshold;

}

float CCFeatureList::lowPassRMSAutocorPeakThreshold() {

	float STD = calculateSTD(mLowPassRMSAutocor, mNumCachedFeatureItems);
	
	mLowPassRMSAutocorPeak = lowPassRMSAutocorPeak();	// Think about putting this kind of stuff in calculateBasicStats...
	
	float threshold = mLowPassRMSAutocorPeak - 2.0 * STD;
	
	mLowPassRMSAutocorPeakThreshold = threshold;
	
//	cout << "\n" << "lowPassAutocor STD = " << STD << "\n";
//	cout << "mLowPassRMSAutocorPeak = " << mLowPassRMSAutocorPeak << "\n";
//	cout << "threshold = " << threshold << "\n";
	
	return mLowPassRMSAutocorPeakThreshold;

}

float CCFeatureList::highPassRMSAutocorPeakThreshold() {

	float STD = calculateSTD(mHighPassRMSAutocor, mNumCachedFeatureItems);
	
	mHighPassRMSAutocorPeak = highPassRMSAutocorPeak();	// Think about putting this kind of stuff in calculateBasicStats...
	
	float threshold = mHighPassRMSAutocorPeak - 2.0 * STD;
	
	mHighPassRMSAutocorPeakThreshold = threshold;
	
//	cout << "\n" << "highPassAutocor STD = " << STD << "\n";
//	cout << "mHighPassRMSAutocorPeak = " << mLowPassRMSAutocorPeak << "\n";
//	cout << "threshold = " << threshold << "\n";
	
	return mHighPassRMSAutocorPeakThreshold;

}
